// Postavljanje tekuće godine u footer
document.getElementById('year').textContent = new Date().getFullYear();